package BankTransaction;

public interface BankTransaction {
    void performTransaction(double amount);
}
