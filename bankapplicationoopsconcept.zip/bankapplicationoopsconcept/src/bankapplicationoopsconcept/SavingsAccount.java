package bankapplicationoopsconcept;

public class SavingsAccount extends Account {
    public SavingsAccount(int accountId, int userId) {
        super(accountId, userId, "Savings");
    }

    @Override
    public void performTransaction(double amount) {
        this.balance += amount;
    }

    @Override
    public void getBalance() {
        System.out.println("Savings Account Balance: $" + balance);
    }
}
