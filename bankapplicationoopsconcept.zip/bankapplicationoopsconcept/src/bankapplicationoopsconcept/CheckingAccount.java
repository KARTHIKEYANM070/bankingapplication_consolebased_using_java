package bankapplicationoopsconcept;

public class CheckingAccount extends Account {
    public CheckingAccount(int accountId, int userId) {
        super(accountId, userId, "Checking");
    }

    @Override
    public void performTransaction(double amount) {
        if (amount <= balance) {
            this.balance -= amount;
        } else {
            System.out.println("Insufficient funds.");
        }
    }

    @Override
    public void getBalance() {
        System.out.println("Checking Account Balance: $" + balance);
    }
}
