package bankapplicationoopsconcept;

import java.sql.*;
import java.util.Scanner;

public class BankingApplication {
    private Connection conn;
    private Scanner scanner;

    public BankingApplication() {
        scanner = new Scanner(System.in);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/banking_app1";
            String username = "root";
            String password = "Karthi@123";
            conn = DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        try {
            System.out.println("Welcome to the Online Banking Application !");

            boolean loggedIn = false;
            int userId = 0;

            while (!loggedIn) {
                System.out.println("1. Register\n2. Login\n3. Exit");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        registerUser();
                        break;
                    case 2:
                        userId = loginUser();
                        loggedIn = userId != 0;
                        break;
                    case 3:
                        System.out.println("Thank you for using the application. Goodbye!");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }

            boolean exit = false;
            while (!exit) {
                System.out.println("Welcome, your AccoutNo" + userId);
                System.out.println("1. Create Account\n2. Deposit\n3. Withdraw\n4. Balance Inquiry\n5. Logout");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        createAccount(userId);
                        break;
                    case 2:
                        performTransaction(userId, "Deposit");
                        break;
                    case 3:
                        performTransaction(userId, "Withdraw");
                        break;
                    case 4:
                        getBalance(userId);
                        break;
                    case 5:
                        exit = true;
                        System.out.println("Logged out. Thank you!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void registerUser() throws SQLException {
        System.out.println("Enter username:");
        String username = scanner.next();
        System.out.println("Enter password:");
        String password = scanner.next();

        String insertUserQuery = "INSERT INTO users (username, password) VALUES (?, ?)";
        try (PreparedStatement statement = conn.prepareStatement(insertUserQuery, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, username);
            statement.setString(2, password);
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected == 1) {
                System.out.println("User registered successfully.");
            } else {
                System.out.println("User registration failed.");
            }
        }
    }

    private int loginUser() throws SQLException {
        System.out.println("Enter username:");
        String username = scanner.next();
        System.out.println("Enter password:");
        String password = scanner.next();

        String selectUserQuery = "SELECT id FROM users WHERE username = ? AND password = ?";
        try (PreparedStatement statement = conn.prepareStatement(selectUserQuery)) {
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getInt("id");
            } else {
                System.out.println("Invalid username or password.");
                return 0;
            }
        }
    }

    private void createAccount(int userId) throws SQLException {
        System.out.println("Choose account type (1. Savings, 2. Checking):");
        int choice = scanner.nextInt();
        String accountType = (choice == 1) ? "Savings" : "Checking";

        String insertAccountQuery = "INSERT INTO accounts (user_id, account_type) VALUES (?, ?)";
        try (PreparedStatement statement = conn.prepareStatement(insertAccountQuery, Statement.RETURN_GENERATED_KEYS)) {
            statement.setInt(1, userId);
            statement.setString(2, accountType);
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected == 1) {
                System.out.println(accountType + " account created successfully.");
            } else {
                System.out.println("Failed to create the account.");
            }
        }
    }

    private void performTransaction(int userId, String transactionType) throws SQLException {
        System.out.println("Enter amount:");
        double amount = scanner.nextDouble();

        String updateBalanceQuery;
        if (transactionType.equals("Deposit")) {
            updateBalanceQuery = "UPDATE accounts SET balance = balance + ? WHERE user_id = ?";
        } else {
            updateBalanceQuery = "UPDATE accounts SET balance = balance - ? WHERE user_id = ?";
        }

        try (PreparedStatement statement = conn.prepareStatement(updateBalanceQuery)) {
            statement.setDouble(1, amount);
            statement.setInt(2, userId);
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected == 1) {
                System.out.println(transactionType + " successful.");
            } else {
                System.out.println(transactionType + " failed.");
            }
        }
    }

    private void getBalance(int userId) throws SQLException {
        String selectBalanceQuery = "SELECT account_type, balance FROM accounts WHERE user_id = ?";
        try (PreparedStatement statement = conn.prepareStatement(selectBalanceQuery)) {
            statement.setInt(1, userId);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String accountType = resultSet.getString("account_type");
                double balance = resultSet.getDouble("balance");
                System.out.println(accountType + " Account Balance: $" + balance);
            }
        }
    }

    public static void main(String[] args) {
        new BankingApplication().run();
    }
}
