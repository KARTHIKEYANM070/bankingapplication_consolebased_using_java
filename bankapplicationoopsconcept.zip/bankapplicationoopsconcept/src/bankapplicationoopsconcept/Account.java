package bankapplicationoopsconcept;

public abstract class Account {
    protected int accountId;
    protected int userId;
    protected String accountType;
    protected double balance;

    public Account(int accountId, int userId, String accountType) {
        this.accountId = accountId;
        this.userId = userId;
        this.accountType = accountType;
        this.balance = 0.0;
    }

    public abstract void performTransaction(double amount);
    public abstract void getBalance();
}

