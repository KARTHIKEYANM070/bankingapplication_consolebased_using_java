/**
 * 
 */
/**
 * @author Karthikeyan M
 *
 */
module bankapplicationoopsconcept {
	requires java.sql;
}